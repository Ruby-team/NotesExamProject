import java.util.ArrayList;
import java.util.List;

public class Main {
    public static int ILE_MASZYN = 2;
    public static List<Task> upList = new ArrayList<>();
    public static List<Task> downList = new ArrayList<>();
    public static List<Task> taskList = new ArrayList<>();
    public static List<Temp> tempList = new ArrayList<>();
    public static void main(String[] args) {

        taskList.add(new Task(1,4,2));
        taskList.add(new Task(2,1,3));
        taskList.add(new Task(3,4,4));
        taskList.add(new Task(4,5,6));
        taskList.add(new Task(5,3,2));

        sort();
        print();
    }

    public static void sort(){

        for(Task tmp : taskList){   //porownujemy gore z dolem
            if(tmp.up<tmp.down) upList.add(tmp);
        }

        for(Task tmp : taskList){   //porownuujemy dol z gora
            if(tmp.up>=tmp.down) downList.add(tmp);
        }

        //sortowanie
        upList.sort((x,y)-> Integer.compare(x.up, y.up));
        upList.forEach(item->System.out.print(item.up));
        System.out.println("");
        downList.sort((x,y)-> Integer.compare(y.down, x.down));
        downList.forEach(item-> System.out.print(item.down));
        System.out.println("");

        //tworzenie na nowo listy
        taskList = new ArrayList<>();
        taskList.addAll(upList);
        taskList.addAll(downList);
        taskList.forEach(item-> System.out.print(item.id + " "));

    }

    public static void print(){
        List<Integer> tmpList = new ArrayList<>();
        int integer=0;

        System.out.println("\n\n####################");
        System.out.println("Z_ID[ile_trwa]");
        System.out.print("M1: ");

        for(Task tmp : taskList){
            System.out.print(" Z"+tmp.id + "[" + tmp.up + "]");
            integer+=tmp.up;
            tmpList.add(integer);
        }

        System.out.println("");
        System.out.println("Z_ID[ile_trwa](kiedy_sie_zaczyna)");
        System.out.print("M2: ");
        int wskaznik=tmpList.get(0)+1;//wskazuje na pierwsza!
        int i=0;
        System.out.print(" Z"+taskList.get(i).id + "[" + taskList.get(i).down + "](" + wskaznik + ")");
        tempList.add(new Temp(taskList.get(i).id, taskList.get(i).down, wskaznik));
        wskaznik=wskaznik+taskList.get(i).down;



        for(i=1;i<taskList.size();i++){
            if(wskaznik<=tmpList.get(i)) wskaznik=tmpList.get(i)+1;
            System.out.print(" Z"+taskList.get(i).id + "[" + taskList.get(i).down + "](" + wskaznik + ")");
            tempList.add(new Temp(taskList.get(i).id, taskList.get(i).down, wskaznik));
            wskaznik=wskaznik+taskList.get(i).down;
        }

        System.out.println("\n\n\n\n");
        String[] tablica = new String[25];
        int x=0;
        for( i=0;i<20;i++){
            if(i<tempList.get(x).kiedySieZaczyna-1) tablica[i]="#";
            else{
                i=tempList.get(x).kiedySieZaczyna-1;
                for(int j=0;j<tempList.get(x).ileTrwa;j++){
                    tablica[i+j]=Integer.toString(tempList.get(x).id);
                }
                i+=tempList.get(x).ileTrwa-1;
                x++;
            }

        }
        for(String tmp : tablica)
            System.out.print(tmp);

    }
}

class Temp {
    int id;
    int ileTrwa;
    int kiedySieZaczyna;

    public Temp(int id, int ileTrwa, int kiedySieZaczyna) {
        this.id=id;
        this.ileTrwa = ileTrwa;
        this.kiedySieZaczyna = kiedySieZaczyna;
    }

    @Override
    public String toString() {
        return  "Z" + id +
                ", ileTrwa=" + ileTrwa +
                ", kiedySieZaczyna=" + kiedySieZaczyna;
    }
}



//        System.out.println("\n\n");
//                System.out.print("M2: ");
//                int wskaznik=tmpList.get(0)+1;
//                int i=0;//to nie jest wazne, to jest wskaznik, ktore wlasnie pobieram z taskList
//                System.out.println("\nwskaznik: "+wskaznik);
//                System.out.print(" Z"+taskList.get(i).id + "[" + taskList.get(i).down + "](" + wskaznik + ")");
//                wskaznik=wskaznik+taskList.get(i).down;
//        i++;
//        System.out.println("\nwskaznik: "+wskaznik);
//        if(wskaznik<=tmpList.get(i)) wskaznik=tmpList.get(i)+1;
//        System.out.print(" Z"+taskList.get(i).id + "[" + taskList.get(i).down + "](" + wskaznik + ")");
//        wskaznik=wskaznik+taskList.get(i).down;
//        i++;
//        System.out.println("\nwskaznik: "+wskaznik);
//        if(wskaznik<=tmpList.get(i)) wskaznik=tmpList.get(i)+1;
//        System.out.print(" Z"+taskList.get(i).id + "[" + taskList.get(i).down + "](" + wskaznik + ")");
//        wskaznik=wskaznik+taskList.get(i).down;
//        i++;
//        System.out.println("\nwskaznik: "+wskaznik);
//        if(wskaznik<=tmpList.get(i)) wskaznik=tmpList.get(i)+1;
//        System.out.print(" Z"+taskList.get(i).id + "[" + taskList.get(i).down + "](" + wskaznik + ")");
//        wskaznik=wskaznik+taskList.get(i).down;
//        i++;
//        System.out.println("\nwskaznik: "+wskaznik);
//        if(wskaznik<=tmpList.get(i)) wskaznik=tmpList.get(i)+1;
//        System.out.print(" Z"+taskList.get(i).id + "[" + taskList.get(i).down + "](" + wskaznik + ")");
//        wskaznik=wskaznik+taskList.get(i).down;
//        System.out.println("\nwskaznik: "+wskaznik);