
public class MTask {
    public int id;
    public int up;
    public int middle;
    public int down;

    public int mup;
    public int mdown;

    public MTask(int id, int up, int middle, int down) {
        this.id = id;
        this.up = up;
        this.middle = middle;
        this.down = down;
        this.mup=up+middle;
        this.mdown=middle+down;
    }

    @Override
    public String toString() {
        return "MTask{" +
                "id=" + id +
                ", up=" + up +
                ", middle=" + middle +
                ", down=" + down +
                ", mup=" + mup +
                ", mdown=" + mdown +
                '}';
    }
}
