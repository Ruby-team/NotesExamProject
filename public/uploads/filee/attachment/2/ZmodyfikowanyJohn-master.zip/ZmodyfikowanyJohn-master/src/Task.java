
public class Task {
    public int id;
    public int up;
    public int down;

    public Task(int id, int up, int down) {
        this.id = id;
        this.up = up;
        this.down = down;
    }

    @Override
    public String toString() {
        return "Z" + id +
                ", up=" + up +
                ", down=" + down;
    }
}
