import java.util.ArrayList;
import java.util.List;

public class ModifiedJohn {
public static List<MTask> taskList = new ArrayList<>();
public static List<MTask> fixedTaskList = new ArrayList<>();
public static List<Temp> tempList = new ArrayList<>(); //M1
public static List<Temp> tempListM2 = new ArrayList<>();

    public static void main(String[] args){
        MTask task = new MTask(1, 4,1,3);
        MTask task1 = new MTask(2,3,3,5);
        MTask task2 = new MTask(3,5,2,4);
        MTask task3 = new MTask(4,6,1,4);
        MTask task4 = new MTask(5,3,2,4);

        addToList(task ); addToList(task1);
        addToList(task2); addToList(task3);
        addToList(task4);
        System.out.println("Przed wykonaniem: ");
        taskList.forEach((tmp)-> System.out.println(tmp));
        getUp();
        M1();
        M2();
        M3();
    }

    public static void addToList(MTask task){
        if(task.middle>task.up) throw new NumberFormatException("M2 dominuje!");
        else taskList.add(task);
    }

    public static void getUp(){
        List<MTask> tmp = new ArrayList<>();
        for(MTask x : taskList){
            if(x.mup<x.mdown) tmp.add(x);
        }
        taskList.removeAll(tmp);//usuwanie uzytych

        tmp.sort((x,y)-> Integer.compare(x.mup, y.mup));


        taskList.sort((x,y)->Integer.compare(y.mdown,x.mdown));


        //sumowanie z obliczen wyzej
        fixedTaskList.addAll(tmp);
        fixedTaskList.addAll(taskList);
        System.out.println("\nKolejnosc wykonywania zadan");
        fixedTaskList.forEach((x)-> System.out.print("Z" + x.id + " " ));
    }

    public static void M1(){
        System.out.println("\n\nM1: ");
        int kiedySieZaczyna = 0;
        for(MTask tmp : fixedTaskList){
            System.out.println(new Temp(tmp.id, tmp.up, kiedySieZaczyna));
            tempList.add(new Temp(tmp.id, tmp.up, kiedySieZaczyna));
            kiedySieZaczyna+=tmp.up;
        }
    }

    public static void M2(){
        System.out.println("\nM2");
        System.out.println(tempList);
        int wskaznik=1;
        int i=0;
        for(Temp tmp : tempList){
            wskaznik=wskaznik + tmp.ileTrwa;
//            System.out.println("wskaznik: " + wskaznik);
            System.out.print(new Temp(tmp.id, fixedTaskList.get(i).middle, wskaznik));
            tempListM2.add(new Temp(tmp.id, fixedTaskList.get(i).middle, wskaznik));
            i++;
        }
    }

    public static void M3(){
        System.out.println("\nM3");
        System.out.println(tempListM2);
        int wskaznik=tempListM2.get(0).kiedySieZaczyna+tempListM2.get(0).ileTrwa;
        int i=0;
        for(Temp tmp : tempListM2){

            System.out.println("wskaznik: " + wskaznik);
            wskaznik+=fixedTaskList.get(0).down;
//            System.out.print(new Temp(tmp.id, fixedTaskList.get(i).down, wskaznik));
            i++;
        }
    }
}


